import React from "react";
import Layout from "../Layout";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Home from "./home/Home";

const Pages = () => {
  return (
    <>
      <BrowserRouter>
        <Layout>
             <Routes>
               <Route path="/" element={<Home/>}/>
             </Routes>
        </Layout>
      </BrowserRouter>
    </>
  );
};

export default Pages;
