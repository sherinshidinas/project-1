import React from "react";

const Home = () => {
  return <div>front</div>;
};

export default Home;
